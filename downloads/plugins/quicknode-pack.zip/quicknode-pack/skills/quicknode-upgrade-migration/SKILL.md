---
name: quicknode-upgrade-migration
description: "QuickNode upgrade migration \u2014 blockchain RPC and Web3 infrastructure\
  \ integration.\nUse when working with QuickNode for blockchain development.\nTrigger\
  \ with phrases like \"quicknode upgrade migration\", \"quicknode-upgrade-migration\"\
  , \"blockchain RPC\".\n"
allowed-tools: Read, Write, Edit, Bash(npm:*), Bash(curl:*), Grep
version: 1.5.0
license: MIT
author: Jeremy Longshore <jeremy@intentsolutions.io>
tags:
- saas
- quicknode
- blockchain
- web3
- rpc
- ethereum
compatibility: Designed for Claude Code
---
# QuickNode Upgrade Migration

## Overview

Implementation patterns for QuickNode upgrade migration using blockchain RPC endpoints and the QuickNode SDK.

## Prerequisites

- Completed `quicknode-install-auth` setup

## Instructions

### Step 1: Connect to QuickNode

```typescript
import { ethers } from 'ethers';
const provider = new ethers.JsonRpcProvider(process.env.QUICKNODE_ENDPOINT);
const block = await provider.getBlockNumber();
console.log(`Connected at block ${block}`);
```

## Output

- QuickNode integration for upgrade migration

## Error Handling

| Error | Cause | Solution |
|-------|-------|----------|
| 401 Unauthorized | Invalid endpoint token | Verify URL from Dashboard |
| Rate limited | Too many requests | Implement backoff or upgrade plan |
| Method not found | Add-on required | Enable in QuickNode Dashboard |

## Resources

- [QuickNode Docs](https://www.quicknode.com/docs/welcome)
- [Ethereum API](https://www.quicknode.com/docs/ethereum)

## Next Steps

See related QuickNode skills for more workflows.
