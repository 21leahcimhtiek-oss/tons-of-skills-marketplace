---
name: retellai-advanced-troubleshooting
description: "Retell AI advanced troubleshooting \u2014 AI voice agent and phone call\
  \ automation.\nUse when working with Retell AI for voice agents, phone calls, or\
  \ telephony.\nTrigger with phrases like \"retell advanced troubleshooting\", \"\
  retellai-advanced-troubleshooting\", \"voice agent\".\n"
allowed-tools: Read, Write, Edit, Bash(npm:*), Bash(curl:*), Grep
version: 1.9.0
license: MIT
author: Jeremy Longshore <jeremy@intentsolutions.io>
tags:
- saas
- retellai
- voice
- telephony
- ai-agents
compatibility: Designed for Claude Code
---
# Retell AI Advanced Troubleshooting

## Overview

Implementation patterns for Retell AI advanced troubleshooting — voice agent and telephony platform.

## Prerequisites

- Completed `retellai-install-auth` setup

## Instructions

### Step 1: SDK Pattern

```typescript
import Retell from 'retell-sdk';
const retell = new Retell({ apiKey: process.env.RETELL_API_KEY! });

const agents = await retell.agent.list();
console.log(`Agents: ${agents.length}`);
```

## Output

- Retell AI integration for advanced troubleshooting

## Error Handling

| Error | Cause | Solution |
|-------|-------|----------|
| 401 Unauthorized | Invalid API key | Check RETELL_API_KEY |
| 429 Rate Limited | Too many requests | Implement backoff |
| 400 Bad Request | Invalid parameters | Check API documentation |

## Examples

### Isolate a voice-call failure without changing production routing

Reproduce the reported failure with a test number and a non-production agent
version. Capture the call identifier, selected agent version, webhook response
code, and timestamp; redact caller audio and personal data from the ticket.
Compare that evidence with one successful test call before changing prompts,
transfers, or routing. Promote the smallest verified correction through the
preview path, then retain the before/after identifiers for rollback.

## Resources

- [Retell AI Documentation](https://docs.retellai.com)
- [retell-sdk npm](https://www.npmjs.com/package/retell-sdk)

## Next Steps

See related Retell AI skills for more workflows.
