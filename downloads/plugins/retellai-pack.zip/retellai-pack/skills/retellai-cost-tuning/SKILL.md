---
name: retellai-cost-tuning
description: "Retell AI cost tuning \u2014 AI voice agent and phone call automation.\n\
  Use when working with Retell AI for voice agents, phone calls, or telephony.\nTrigger\
  \ with phrases like \"retell cost tuning\", \"retellai-cost-tuning\", \"voice agent\"\
  .\n"
allowed-tools: Read, Write, Edit, Bash(npm:*), Bash(curl:*), Grep
version: 1.9.0
license: MIT
author: Jeremy Longshore <jeremy@intentsolutions.io>
tags:
- saas
- retellai
- voice
- telephony
- ai-agents
compatibility: Designed for Claude Code
---
# Retell AI Cost Tuning

## Overview

Implementation patterns for Retell AI cost tuning — voice agent and telephony platform.

## Prerequisites

- Completed `retellai-install-auth` setup

## Instructions

### Step 1: SDK Pattern

```typescript
import Retell from 'retell-sdk';
const retell = new Retell({ apiKey: process.env.RETELL_API_KEY! });

const agents = await retell.agent.list();
console.log(`Agents: ${agents.length}`);
```

## Output

- Retell AI integration for cost tuning

## Error Handling

| Error | Cause | Solution |
|-------|-------|----------|
| 401 Unauthorized | Invalid API key | Check RETELL_API_KEY |
| 429 Rate Limited | Too many requests | Implement backoff |
| 400 Bad Request | Invalid parameters | Check API documentation |

## Examples

### Reduce cost without degrading a required human handoff

Measure average call duration, transfer rate, and failed-call retries for a
representative non-production sample before changing prompt length or model
settings. Trial the lower-cost configuration on a small canary, retaining the
existing agent version as rollback. Keep the human-handoff trigger unchanged
unless the service owner approves a new threshold; a shorter call is not a
saving if it silently increases unresolved customer requests.

## Resources

- [Retell AI Documentation](https://docs.retellai.com)
- [retell-sdk npm](https://www.npmjs.com/package/retell-sdk)

## Next Steps

See related Retell AI skills for more workflows.
