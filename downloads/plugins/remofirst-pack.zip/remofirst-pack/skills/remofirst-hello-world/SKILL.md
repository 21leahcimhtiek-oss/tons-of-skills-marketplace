---
name: remofirst-hello-world
description: "RemoFirst hello world \u2014 global HR, EOR, and payroll platform integration.\n\
  Use when working with RemoFirst for global employment, payroll, or compliance.\n\
  Trigger with phrases like \"remofirst hello world\", \"remofirst-hello-world\",\
  \ \"global HR API\".\n"
allowed-tools: Read, Write, Edit, Bash(npm:*), Bash(curl:*), Grep
version: 1.4.0
license: MIT
author: Jeremy Longshore <jeremy@intentsolutions.io>
tags:
- saas
- remofirst
- hr
- eor
- payroll
- global-employment
compatibility: Designed for Claude Code
---
# RemoFirst Hello World

## Overview

Implementation patterns for RemoFirst hello world — global HR and EOR platform integration.

## Prerequisites

- Completed `remofirst-install-auth` setup

## Instructions

### Step 1: API Pattern

```python
client = RemoFirstClient()
employees = client.get("/employees", params={"page_size": 10})
print(f"Employees: {len(employees['data'])}")
```

## Output

- RemoFirst integration for hello world

## Error Handling

| Error | Cause | Solution |
|-------|-------|----------|
| 401 Unauthorized | Invalid API key | Contact RemoFirst support |
| 429 Rate Limited | Too many requests | Implement backoff |
| 422 Validation Error | Missing required field | Check API documentation |

## Resources

- [RemoFirst](https://www.remofirst.com)

## Next Steps

See related RemoFirst skills for more workflows.
