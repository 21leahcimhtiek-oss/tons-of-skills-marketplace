# Assets for overnight-dev
