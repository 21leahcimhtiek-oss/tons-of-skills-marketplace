# Vulnerable code examples

The inventory below describes the example snippets included in this Markdown document; it is not
a ZIP archive.

```text
Archive: vulnerable-code-examples.md
  Length      Date    Time    Name
---------  ---------- -----   ----
      376  2024-02-29 14:23   php/sqli.php
      289  2024-02-29 14:23   python/xss.py
      412  2024-02-29 14:23   java/command_injection.java
      314  2024-02-29 14:23   README.txt
---------                     -------
     1391                     4 files
```

# README.txt

This document contains example code snippets with common input-validation vulnerabilities. These
examples are for demonstration purposes only and must not be used in production code.

Each directory (php, python, java) contains a file demonstrating a specific vulnerability.

* php/sqli.php: Demonstrates SQL injection vulnerability.
* python/xss.py: Demonstrates Cross-Site Scripting (XSS) vulnerability.
* java/command_injection.java: Demonstrates Command Injection vulnerability.

Review these examples carefully to understand the risks associated with improper input validation.

# Placeholders:

* REPLACE_WITH_USER_INPUT:  Indicates a place where user input is directly used without validation.
* REPLACE_WITH_DATABASE_CREDENTIALS: Placeholder for actual database credentials. DO NOT commit real credentials.

```php
<?php
// php/sqli.php
// Example of SQL injection vulnerability

$username = $_GET['username']; // REPLACE_WITH_USER_INPUT: User input taken directly from GET request
$password = $_GET['password']; // REPLACE_WITH_USER_INPUT: User input taken directly from GET request

// Vulnerable query - DO NOT USE IN PRODUCTION
$query = "SELECT * FROM users WHERE username = '" . $username . "' AND password = '" . $password . "'";

// Simulate database connection and query execution (for demonstration purposes)
// In a real application, you would use mysqli_query or PDO
echo "Executing query: " . $query . "<br>";

// The following lines are for demonstration and will NOT connect to a database
// Replace this with your actual database connection and query execution
$result = false; // Simulate a failed query

if ($result) {
    echo "Login successful!";
} else {
    echo "Login failed!";
}

// Mitigation: Use prepared statements with parameterized queries to prevent SQL injection.
?>
```

```python
# python/xss.py
# Example of Cross-Site Scripting (XSS) vulnerability

from flask import Flask, request, render_template_string

app = Flask(__name__)

@app.route('/')
def index():
    name = request.args.get('name', 'World') # REPLACE_WITH_USER_INPUT: User input taken directly from GET request
    # Vulnerable code - DO NOT USE IN PRODUCTION
    template = f"<h1>Hello, {name}!</h1>" # Direct insertion of user input into HTML
    return render_template_string(template)

if __name__ == '__main__':
    app.run(debug=True)

# Mitigation: Use proper escaping techniques to sanitize user input before rendering it in HTML.
# For example, use Jinja2's autoescape feature or escape the input using a library like bleach.
```

```java
// java/command_injection.java
// Example of Command Injection vulnerability

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjection {

    public static void main(String[] args) {
        String userInput = System.console().readLine("Enter a URL to ping: "); // REPLACE_WITH_USER_INPUT: User input taken directly from console

        try {
            // Vulnerable code - DO NOT USE IN PRODUCTION
            Process process = Runtime.getRuntime().exec("ping " + userInput); // Directly concatenating user input into a system command

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Mitigation:  Avoid using Runtime.getRuntime().exec() with user-provided input.
        // If necessary, use a whitelist of allowed characters and escape any special characters.
        // Consider using a library or API specifically designed for the task instead of executing shell commands.
    }
}
```
